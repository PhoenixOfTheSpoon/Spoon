(function(){
const A = window.Arcade, C = A.C, el = A.el;
const board = (host, bg=C.forest) => { const b = el('div',{width:'480px',height:'480px',background:bg,borderRadius:'12px',position:'relative',fontFamily:A.font,overflow:'hidden',userSelect:'none'}); host.appendChild(b); return b; };
const btn = (txt, fn) => { const b = el('button',{fontFamily:A.font,fontWeight:700,fontSize:'16px',padding:'12px 22px',borderRadius:'999px',border:'none',background:C.lime,color:C.forest,cursor:'pointer'},txt); b.onclick=fn; return b; };
const splash = (b, big, small, label, fn) => { const o = el('div',{position:'absolute',inset:0,background:'rgba(1,86,64,.9)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:'12px',color:'#fff',textAlign:'center',zIndex:5});
  o.append(el('div',{fontSize:'34px',fontWeight:700,color:C.lime},big), el('div',{fontSize:'16px',fontWeight:500,maxWidth:'340px'},small), btn(label,()=>{o.remove();fn();})); b.appendChild(o); return o; };
A.ui = { board, btn, splash };

A.register('memory', { mount(host, api){
  const b = board(host); let timer;
  const icons = ['▲','●','■','◆','★','✚','☾','♣','✿','♥'], cols=[C.lime,C.pink,C.sky,C.gold,C.lavender,C.peach,C.mint,C.orange,C.red,C.sand];
  const start = () => {
    b.innerHTML=''; const NP=A.D(6,8,10), deck = [...Array(NP*2)].map((_,i)=>i%NP).sort(()=>Math.random()-.5);
    let open=[], found=0, moves=0, lock=false, t0=Date.now(); cards=[];
    const grid = el('div',{display:'grid',gridTemplateColumns:'repeat('+A.D(4,4,5)+',1fr)',gap:'10px',padding:'20px',height:'100%',boxSizing:'border-box'}); b.appendChild(grid);
    deck.forEach(v=>{ const c = el('div',{background:C.green,borderRadius:'12px',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'44px',color:'transparent',cursor:'pointer',transition:'background .18s'},icons[v]);
      c.onclick=()=>{ if(lock||c.dataset.o)return; c.dataset.o=1; c.style.background=C.cream; c.style.color=cols[v]==C.lime?C.forest:cols[v]; A.sfx('flip'); open.push([c,v]);
        if(open.length==2){ moves++; const [[a,x],[d,y]]=open; open=[];
          if(x==y){found++;A.sfx('point');a.style.background=d.style.background=cols[x];a.style.color=d.style.color=C.forest;
            const sc=Math.max(0,1000-moves*25-Math.floor((Date.now()-t0)/1000)*5); api.score(sc);
            if(found==NP){A.sfx('win');setTimeout(()=>{api.over(sc);splash(b,'ALL MATCHED',moves+' moves · score '+sc,'Deal again',start);},500);} }
          else{lock=true;A.sfx('bad');setTimeout(()=>{[a,d].forEach(k=>{delete k.dataset.o;k.style.background=C.green;k.style.color='transparent';});lock=false;},650/A.speed);} } };
      grid.appendChild(c); cards.push([c,v]); });
    api.score(0); hints.reset();
  };
  let cards=[]; const hints=A.hinter(api,()=>{ const un=cards.filter(([c])=>!c.dataset.o); if(!un.length)return false; const v=un[Math.random()*un.length|0][1]; un.filter(x=>x[1]==v).forEach(([c])=>A.pulse(c,C.gold,1300)); });
  splash(b,'MEMORY MATCH','Flip two cards. Find every pair in as few moves as you can.','Deal cards',start);
  return ()=>clearTimeout(timer);
}});

A.register('whack', { mount(host, api){
  const b = board(host, C.bark); let iv, to, running=false;
  const start = () => {
    b.innerHTML=''; let score=0, left=30; api.score(0); running=true;
    const hud = el('div',{position:'absolute',top:'12px',left:'16px',right:'16px',display:'flex',justifyContent:'space-between',color:C.cream,fontWeight:700,fontSize:'18px'}); b.appendChild(hud);
    const draw=()=>hud.textContent=''; const sT=el('span'), sS=el('span'); hud.append(sS,sT);
    const grid = el('div',{position:'absolute',top:'56px',left:'30px',right:'30px',bottom:'30px',display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'18px'}); b.appendChild(grid);
    const holes=[...Array(9)].map(()=>{ const h=el('div',{background:'#5a3a12',borderRadius:'50%',position:'relative',overflow:'hidden',cursor:'crosshair'});
      const m=el('div',{position:'absolute',left:'15%',width:'70%',height:'80%',top:'100%',background:C.sand,borderRadius:'50% 50% 30% 30%',transition:'top .12s ease-out',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'28px',fontWeight:700,color:C.ink},'• •');
      h.appendChild(m); h.m=m; m.onmousedown=e=>{ if(!m.up)return; m.up=0; m.style.top='100%'; score+=m.gold?30:10; api.score(score); A.sfx(m.gold?'coin':'hit'); }; grid.appendChild(h); return h; });
    const upd=()=>{sS.textContent='Score '+score;sT.textContent=left+'s';}; upd();
    const pop=()=>{ if(!running)return; const h=holes[Math.random()*9|0]; if(!h.m.up){ const gold=Math.random()<.15; h.m.gold=gold; h.m.style.background=gold?C.gold:C.sand; h.m.up=1; h.m.style.top='20%';
        setTimeout(()=>{h.m.up=0;h.m.style.top='100%';},Math.max(450,900-(30-left)*15)*A.D(1.35,1,.7)/A.speed); }
      to=setTimeout(pop,Math.max(300,700-(30-left)*14)*A.D(1.3,1,.72)/A.speed); upd(); };
    pop(); iv=setInterval(()=>{ left--; upd(); if(left<=0){ running=false; clearInterval(iv); clearTimeout(to); A.sfx('over'); api.over(score); splash(b,'TIME',score+' points. Gold critters are worth triple.','Play again',start);} },1000);
  };
  splash(b,'WHACK-A-GOPHER','30 seconds. Click them as they pop up. Gold ones pay triple.','Start',start);
  return ()=>{running=false;clearInterval(iv);clearTimeout(to);};
}});

A.register('2048', { mount(host, api){
  const b = board(host, C.sand); const shades={2:'#EDE9D8',4:'#e4f7a8',8:C.lime,16:'#9fe07a',32:C.green,64:'#028a4e',128:C.forest,256:C.sky,512:C.blue,1024:C.pink,2048:C.gold};
  let G, score, over=false;
  const grid = el('div',{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'10px',padding:'16px',height:'100%'}); b.appendChild(grid);
  const cells=[...Array(16)].map(()=>{const c=el('div',{borderRadius:'10px',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:'36px'});grid.appendChild(c);return c;});
  const add=()=>{const e=[];G.forEach((v,i)=>!v&&e.push(i));if(e.length)G[e[Math.random()*e.length|0]]=Math.random()<.9?2:4;};
  const paint=()=>G.forEach((v,i)=>{const c=cells[i];c.textContent=v||'';c.style.background=v?(shades[v]||C.magenta||'#AB2372'):'rgba(255,255,255,.35)';c.style.color=v>=32?'#fff':C.forest;c.style.fontSize=v>=1024?'28px':'36px';});
  const reset=()=>{G=Array(16).fill(0);score=0;over=false;add();add();paint();api.score(0);};
  const slide=row=>{let a=row.filter(v=>v);for(let i=0;i<a.length-1;i++)if(a[i]==a[i+1]){a[i]*=2;score+=a[i];a.splice(i+1,1);}while(a.length<4)a.push(0);return a;};
  const move=d=>{ if(over)return; const old=G.join();
    for(let k=0;k<4;k++){ let idx=[0,1,2,3].map(j=>d=='L'||d=='R'?k*4+j:j*4+k); if(d=='R'||d=='D')idx.reverse(); const r=slide(idx.map(i=>G[i])); idx.forEach((i,j)=>G[i]=r[j]); }
    if(G.join()!=old){add();A.sfx('blip');api.score(score);paint();
      const can=G.some((v,i)=>!v||(i%4<3&&v==G[i+1])||(i<12&&v==G[i+4])); if(!can){over=true;A.sfx('over');api.over(score);splash(b,'NO MOVES LEFT','Score '+score+' · best tile '+Math.max(...G),'New board',reset);}} };
  const offK=A.keys(e=>{const d={ArrowLeft:'L',ArrowRight:'R',ArrowUp:'U',ArrowDown:'D',a:'L',d:'R',w:'U',s:'D'}[e.key];if(d)move(d);});
  reset(); return offK;
}});

A.register('tictactoe', { mount(host, api){
  const b = board(host, C.cream); let wins=0, to;
  let hintFn=()=>false; const hints=A.hinter(api,()=>hintFn());
  const lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const winner=s=>{for(const[a,c,d]of lines)if(s[a]&&s[a]==s[c]&&s[a]==s[d])return s[a];return s.every(x=>x)?'D':null;};
  const ai=s=>{ const tryW=p=>{for(const l of lines){const v=l.map(i=>s[i]);if(v.filter(x=>x==p).length==2&&v.includes(null))return l[v.indexOf(null)];}return -1;};
    let m=tryW('O'); if(m<0)m=tryW('X'); if(m<0&&!s[4])m=4; if(m<0||Math.random()<A.D(.5,.15,0)){const e=s.map((v,i)=>v?-1:i).filter(i=>i>=0);m=e[Math.random()*e.length|0];} return m; };
  const start=()=>{ b.innerHTML=''; const s=Array(9).fill(null); let busy=false;
    const info=el('div',{textAlign:'center',fontWeight:700,fontSize:'20px',color:C.forest,padding:'16px'},'Your move · you are X · streak '+wins); b.appendChild(info);
    const grid=el('div',{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'8px',width:'380px',height:'380px',margin:'0 auto',background:C.forest,padding:'8px',borderRadius:'14px'}); b.appendChild(grid);
    const cs=s.map((_,i)=>{const c=el('div',{background:C.cream,borderRadius:'8px',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'72px',fontWeight:700,cursor:'pointer'});c.onclick=()=>play(i);grid.appendChild(c);return c;});
    hintFn=()=>{ if(busy||winner(s))return false; const sw=s.map(v=>v=='X'?'O':v=='O'?'X':null); const old=A.diff; A.diff='hard'; const m=ai(sw); A.diff=old; A.pulse(cs[m],C.gold); }; hints.reset();
    const put=(i,p)=>{s[i]=p;cs[i].textContent=p=='X'?'✕':'◯';cs[i].style.color=p=='X'?C.green:C.pink;};
    const end=w=>{ if(w=='X'){wins++;A.sfx('win');}else if(w=='O'){A.sfx('over');}else A.sfx('blip');
      const sc=w=='X'?wins*100:w=='D'?50:0; api.score(sc); api.over(sc); if(w=='O')wins=0;
      to=setTimeout(()=>splash(b,w=='X'?'YOU WIN':w=='O'?'CPU WINS':'DRAW',w=='X'?'Streak: '+wins+'. Keep it going.':w=='O'?'Streak reset.':'Nobody blinks.','Next round',start),500); };
    function play(i){ if(busy||s[i])return; put(i,'X'); A.sfx('blip'); let w=winner(s); if(w)return end(w);
      busy=true; info.textContent='CPU thinking…'; to=setTimeout(()=>{put(ai(s),'O');A.sfx('flip');busy=false;info.textContent='Your move · streak '+wins;const w2=winner(s);if(w2)end(w2);},400); }
  };
  start(); return ()=>clearTimeout(to);
}});
})();
